create
  definer = root@localhost procedure catalog_assign_product_to_category(IN inProductId int, IN inCategoryId int)
BEGIN
  INSERT INTO product_category (product_id, category_id)
  VALUES (inProductId, inCategoryId);
END;

