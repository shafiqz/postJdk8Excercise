create
  definer = root@localhost procedure catalog_assign_attribute_value_to_product(IN inProductId int, IN inAttributeValueId int)
BEGIN
  INSERT INTO product_attribute (product_id, attribute_value_id)
  VALUES (inProductId, inAttributeValueId);
END;

