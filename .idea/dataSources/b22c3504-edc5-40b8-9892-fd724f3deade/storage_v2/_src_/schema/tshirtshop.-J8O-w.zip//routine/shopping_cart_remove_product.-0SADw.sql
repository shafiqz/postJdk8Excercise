create
  definer = root@localhost procedure shopping_cart_remove_product(IN inItemId int)
BEGIN
  DELETE FROM shopping_cart WHERE item_id = inItemId;
END;

