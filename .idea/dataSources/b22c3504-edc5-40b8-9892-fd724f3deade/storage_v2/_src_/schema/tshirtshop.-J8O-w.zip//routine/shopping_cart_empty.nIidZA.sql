create
  definer = root@localhost procedure shopping_cart_empty(IN inCartId char(32))
BEGIN
  DELETE FROM shopping_cart WHERE cart_id = inCartId;
END;

