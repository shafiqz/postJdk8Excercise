create
  definer = root@localhost procedure catalog_set_image_2(IN inProductId int, IN inImage varchar(150))
BEGIN
  UPDATE product SET image_2 = inImage WHERE product_id = inProductId;
END;

