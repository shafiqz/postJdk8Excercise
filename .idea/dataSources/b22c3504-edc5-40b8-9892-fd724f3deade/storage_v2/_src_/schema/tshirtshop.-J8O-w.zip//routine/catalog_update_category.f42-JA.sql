create
  definer = root@localhost procedure catalog_update_category(IN inCategoryId int,
                                                             IN inName varchar(100),
                                                             IN inDescription varchar(1000))
BEGIN
  UPDATE category
  SET    name = inName, description = inDescription
  WHERE  category_id = inCategoryId;
END;

