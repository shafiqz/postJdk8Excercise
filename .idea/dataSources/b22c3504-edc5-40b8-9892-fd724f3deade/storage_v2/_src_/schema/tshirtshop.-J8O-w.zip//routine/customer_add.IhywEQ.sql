create
  definer = root@localhost procedure customer_add(IN inName varchar(50),
                                                  IN inEmail varchar(100),
                                                  IN inPassword varchar(50))
BEGIN
  INSERT INTO customer (name, email, password)
  VALUES (inName, inEmail, inPassword);

  SELECT LAST_INSERT_ID();
END;

