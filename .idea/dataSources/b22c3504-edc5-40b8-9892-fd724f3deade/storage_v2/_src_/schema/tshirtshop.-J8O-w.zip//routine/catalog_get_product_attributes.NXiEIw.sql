create
  definer = root@localhost procedure catalog_get_product_attributes(IN inProductId int)
BEGIN
  SELECT     a.name AS attribute_name,
             av.attribute_value_id, av.value AS attribute_value
  FROM       attribute_value av
               INNER JOIN attribute a
                          ON av.attribute_id = a.attribute_id
  WHERE      av.attribute_value_id IN
             (SELECT attribute_value_id
              FROM   product_attribute
              WHERE  product_id = inProductId)
  ORDER BY   a.name;
END;

