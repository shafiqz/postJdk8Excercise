create
  definer = root@localhost procedure catalog_set_image(IN inProductId int, IN inImage varchar(150))
BEGIN
  UPDATE product SET image = inImage WHERE product_id = inProductId;
END;

