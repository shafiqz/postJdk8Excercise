create
  definer = root@localhost procedure catalog_update_attribute_value(IN inAttributeValueId int,
                                                                    IN inValue varchar(100))
BEGIN
  UPDATE attribute_value
  SET    value = inValue
  WHERE  attribute_value_id = inAttributeValueId;
END;

