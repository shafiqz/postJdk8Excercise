create
  definer = root@localhost procedure catalog_get_attribute_details(IN inAttributeId int)
BEGIN
  SELECT attribute_id, name
  FROM   attribute
  WHERE  attribute_id = inAttributeId;
END;

