create
  definer = root@localhost procedure catalog_get_product_locations(IN inProductId int)
BEGIN
  SELECT c.category_id, c.name AS category_name, c.department_id,
         (SELECT name
          FROM   department
          WHERE  department_id = c.department_id) AS department_name
         -- Subquery returns the name of the department of the category
  FROM   category c
  WHERE  c.category_id IN
         (SELECT category_id
          FROM   product_category
          WHERE  product_id = inProductId);
  -- Subquery returns the category IDs a product belongs to
END;

