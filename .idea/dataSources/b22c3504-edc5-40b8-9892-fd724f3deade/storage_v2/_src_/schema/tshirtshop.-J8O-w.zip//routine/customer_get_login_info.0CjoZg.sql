create
  definer = root@localhost procedure customer_get_login_info(IN inEmail varchar(100))
BEGIN
  SELECT customer_id, password FROM customer WHERE email = inEmail;
END;

