create
  definer = root@localhost procedure catalog_get_category_name(IN inCategoryId int)
BEGIN
  SELECT name FROM category WHERE category_id = inCategoryId;
END;

