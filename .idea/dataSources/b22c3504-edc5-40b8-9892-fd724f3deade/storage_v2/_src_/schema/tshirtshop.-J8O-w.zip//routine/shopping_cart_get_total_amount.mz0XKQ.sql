create
  definer = root@localhost procedure shopping_cart_get_total_amount(IN inCartId char(32))
BEGIN
  SELECT     SUM(COALESCE(NULLIF(p.discounted_price, 0), p.price)
    * sc.quantity) AS total_amount
  FROM       shopping_cart sc
               INNER JOIN product p
                          ON sc.product_id = p.product_id
  WHERE      sc.cart_id = inCartId AND sc.buy_now;
END;

