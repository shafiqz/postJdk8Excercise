create
  definer = root@localhost procedure orders_get_orders_by_status(IN inStatus int)
BEGIN
  SELECT     o.order_id, o.total_amount, o.created_on,
             o.shipped_on, o.status, c.name
  FROM       orders o
               INNER JOIN customer c
                          ON o.customer_id = c.customer_id
  WHERE      o.status = inStatus
  ORDER BY   o.created_on DESC;
END;

