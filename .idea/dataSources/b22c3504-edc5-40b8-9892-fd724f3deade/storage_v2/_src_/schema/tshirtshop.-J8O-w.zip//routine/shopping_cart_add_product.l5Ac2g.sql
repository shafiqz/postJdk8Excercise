create
  definer = root@localhost procedure shopping_cart_add_product(IN inCartId char(32),
                                                               IN inProductId int,
                                                               IN inAttributes varchar(1000))
BEGIN
  DECLARE productQuantity INT;

  -- Obtain current shopping cart quantity for the product
  SELECT quantity
  FROM   shopping_cart
  WHERE  cart_id = inCartId
    AND product_id = inProductId
    AND attributes = inAttributes
    INTO   productQuantity;

  -- Create new shopping cart record, or increase quantity of existing record
  IF productQuantity IS NULL THEN
    INSERT INTO shopping_cart(item_id, cart_id, product_id, attributes,
                              quantity, added_on)
    VALUES (UUID(), inCartId, inProductId, inAttributes, 1, NOW());
  ELSE
    UPDATE shopping_cart
    SET    quantity = quantity + 1, buy_now = true
    WHERE  cart_id = inCartId
      AND product_id = inProductId
      AND attributes = inAttributes;
  END IF;
END;

