create
  definer = root@localhost procedure catalog_move_product_to_category(IN inProductId int,
                                                                      IN inSourceCategoryId int,
                                                                      IN inTargetCategoryId int)
BEGIN
  UPDATE product_category
  SET    category_id = inTargetCategoryId
  WHERE  product_id = inProductId
    AND category_id = inSourceCategoryId;
END;

