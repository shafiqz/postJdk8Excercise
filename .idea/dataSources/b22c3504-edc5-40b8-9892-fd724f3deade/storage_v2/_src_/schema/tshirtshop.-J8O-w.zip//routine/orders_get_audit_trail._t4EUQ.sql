create
  definer = root@localhost procedure orders_get_audit_trail(IN inOrderId int)
BEGIN
  SELECT audit_id, order_id, created_on, message, code
  FROM   audit
  WHERE  order_id = inOrderId;
END;

