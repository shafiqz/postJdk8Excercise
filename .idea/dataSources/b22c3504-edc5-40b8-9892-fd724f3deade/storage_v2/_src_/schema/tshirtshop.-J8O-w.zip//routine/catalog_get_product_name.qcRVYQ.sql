create
  definer = root@localhost procedure catalog_get_product_name(IN inProductId int)
BEGIN
  SELECT name FROM product WHERE product_id = inProductId;
END;

