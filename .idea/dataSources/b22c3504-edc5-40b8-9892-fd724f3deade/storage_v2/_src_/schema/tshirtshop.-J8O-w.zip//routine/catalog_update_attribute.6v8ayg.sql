create
  definer = root@localhost procedure catalog_update_attribute(IN inAttributeId int, IN inName varchar(100))
BEGIN
  UPDATE attribute SET name = inName WHERE attribute_id = inAttributeId;
END;

