create
  definer = root@localhost procedure catalog_get_departments_list()
BEGIN
  SELECT department_id, name FROM department ORDER BY department_id;
END;

