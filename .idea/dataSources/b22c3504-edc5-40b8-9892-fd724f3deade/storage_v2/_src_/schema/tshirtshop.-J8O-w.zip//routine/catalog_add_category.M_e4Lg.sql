create
  definer = root@localhost procedure catalog_add_category(IN inDepartmentId int,
                                                          IN inName varchar(100),
                                                          IN inDescription varchar(1000))
BEGIN
  INSERT INTO category (department_id, name, description)
  VALUES (inDepartmentId, inName, inDescription);
END;

