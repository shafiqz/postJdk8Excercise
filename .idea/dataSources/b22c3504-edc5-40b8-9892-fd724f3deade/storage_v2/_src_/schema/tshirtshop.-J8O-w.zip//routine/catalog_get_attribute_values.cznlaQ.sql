create
  definer = root@localhost procedure catalog_get_attribute_values(IN inAttributeId int)
BEGIN
  SELECT   attribute_value_id, value
  FROM     attribute_value
  WHERE    attribute_id = inAttributeId
  ORDER BY attribute_id;
END;

