create
  definer = root@localhost procedure catalog_delete_attribute_value(IN inAttributeValueId int)
BEGIN
  DECLARE productAttributeRowsCount INT;

  SELECT      count(*)
  FROM        product p
                INNER JOIN  product_attribute pa
                            ON p.product_id = pa.product_id
  WHERE       pa.attribute_value_id = inAttributeValueId
              INTO        productAttributeRowsCount;

  IF productAttributeRowsCount = 0 THEN
    DELETE FROM attribute_value WHERE attribute_value_id = inAttributeValueId;

    SELECT 1;
  ELSE
    SELECT -1;
  END IF;
END;

