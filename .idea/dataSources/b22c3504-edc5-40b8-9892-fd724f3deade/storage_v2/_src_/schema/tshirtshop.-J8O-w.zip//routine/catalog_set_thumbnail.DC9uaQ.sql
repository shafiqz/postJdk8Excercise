create
  definer = root@localhost procedure catalog_set_thumbnail(IN inProductId int,
                                                           IN inThumbnail varchar(150))
BEGIN
  UPDATE product
  SET    thumbnail = inThumbnail
  WHERE  product_id = inProductId;
END;

