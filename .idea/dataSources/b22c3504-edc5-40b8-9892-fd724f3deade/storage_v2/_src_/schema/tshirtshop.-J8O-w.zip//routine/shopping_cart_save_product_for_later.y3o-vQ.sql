create
  definer = root@localhost procedure shopping_cart_save_product_for_later(IN inItemId int)
BEGIN
  UPDATE shopping_cart
  SET    buy_now = false, quantity = 1
  WHERE  item_id = inItemId;
END;

