create
  definer = root@localhost procedure orders_get_orders_between_dates(IN inStartDate datetime, IN inEndDate datetime)
BEGIN
  SELECT     o.order_id, o.total_amount, o.created_on,
             o.shipped_on, o.status, c.name
  FROM       orders o
               INNER JOIN customer c
                          ON o.customer_id = c.customer_id
  WHERE      o.created_on >= inStartDate AND o.created_on <= inEndDate
  ORDER BY   o.created_on DESC;
END;

